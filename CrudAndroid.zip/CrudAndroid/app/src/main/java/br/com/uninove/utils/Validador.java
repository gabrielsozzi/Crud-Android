package br.com.uninove.utils;

import android.widget.EditText;

public class Validador {

    public static String validar(EditText nome, EditText curso, EditText ra){
        if(     curso.getText().toString().trim().isEmpty() || curso == null ||
                nome.getText().toString().trim().isEmpty() || nome == null ||
                ra.getText().toString().trim().isEmpty() || ra == null ) {
            return "Por favor preencha todos os campos";
        }
        // caso o numero informado seja invalido sera retornado um msg
        try{
            Double.parseDouble(ra.getText().toString());
        }catch(NumberFormatException ex){
            return "Campo valor deve ser numérico";
        }

        return null;
    }

}
