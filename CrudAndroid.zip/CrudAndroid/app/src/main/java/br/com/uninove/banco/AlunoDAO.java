package br.com.uninove.banco;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import br.com.uninove.model.Aluno;

public class AlunoDAO {

    private Conexao conexao;
    private SQLiteDatabase bd;

    public  AlunoDAO(Context context){
        conexao = new Conexao(context);
        bd = conexao.getWritableDatabase();
    }

    public long inserir (Aluno aluno){
        // Valores que serão inseridos no Banco de dados
        ContentValues values = new ContentValues();
        values.put("nome", aluno.getNome());
        values.put("curso", aluno.getCurso());
        values.put("ra", aluno.getRA());

        // Retorna ALuno inserido
       return  bd.insert("aluno",null,values);
    }

    public List<Aluno> listarTodos (){
        List<Aluno> alunos = new ArrayList<Aluno>();

        // Função de Select
        Cursor cursor = bd.query("aluno",
                new String[]{"id","nome","ra","curso"},
                null,null,null,null,null);

        while(cursor.moveToNext()){
            Aluno aluno = new Aluno();
            aluno.setId(cursor.getLong(0));
            aluno.setNome(cursor.getString(1));
            aluno.setRA(cursor.getDouble(2));
            aluno.setCurso(cursor.getString(3));
            alunos.add(aluno);
        }

        return alunos;
    }

    // Função de delete
    public void excluir(Aluno p){
        bd.delete("aluno","id = ?" , new String[]{p.getId().toString()});
    }


    // FUnção de Update
    public void atualizar(Aluno aluno) {
        ContentValues values = new ContentValues();
        values.put("nome", aluno.getNome());
        values.put("curso", aluno.getCurso());
        values.put("RA", aluno.getRA());
        bd.update("aluno",values, "id = ?", new String[]{aluno.getId().toString()});
    }
}
