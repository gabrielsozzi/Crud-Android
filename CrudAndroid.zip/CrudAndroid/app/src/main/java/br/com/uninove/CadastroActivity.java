package br.com.uninove;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import br.com.uninove.banco.AlunoDAO;
import br.com.uninove.model.Aluno;
import br.com.uninove.utils.Validador;

public class CadastroActivity extends AppCompatActivity {

    private EditText nome, curso,ra;
    private AlunoDAO dao;
    private Aluno aluno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        // Relacionando ob JAVA XML
        nome = findViewById(R.id.editNome);
        curso = findViewById(R.id.editCurso);
        ra = findViewById(R.id.editRA);

        // Classe do AlunoDAO passando como parâmetro
        dao = new AlunoDAO(this);

        // Verifica se existe ALuno extra
        Intent it = getIntent();
        if (it.hasExtra("aluno")) {
            aluno = (Aluno) it.getSerializableExtra("aluno");
            nome.setText(aluno.getNome());
            curso.setText(aluno.getCurso());
            ra.setText(aluno.getRA().toString());
        }
    }



    private Aluno criarAluno(EditText nome, EditText curso, EditText ra){
        // verificando se nao existe nenhum erro na validacao do form
        if(Validador.validar(nome,curso,ra) == null){
            aluno.setCurso(curso.getText().toString().trim());
            aluno.setNome(nome.getText().toString().trim());
            aluno.setRA(Double.parseDouble(ra.getText().toString().trim()));
      // Caso exista erro no form mostrar maneira adequada
       }else{
            Toast toast = Toast.makeText(this,Validador.validar(nome,curso,ra), Toast.LENGTH_SHORT);
            TextView v = (TextView) toast.getView().findViewById(android.R.id.message);
            v.setTextColor(Color.RED);
            toast.show();
        }
        return aluno;
    }



    // Método para salvar/atualizar aluno de acordo com a opção correta
    public void salvarOuAtualizar(View view){
        // caso nao exista aluno no extra sera chamado o metodo inserir
        if(aluno == null){
            aluno = new Aluno();
            // valida preenchimento form
            if(Validador.validar(nome,curso,ra) == null){
                aluno.setCurso(curso.getText().toString().trim());
                aluno.setNome(nome.getText().toString().trim());
                aluno.setRA(Double.parseDouble(ra.getText().toString().trim()));

                // salvando aluno no banco
                long id = dao.inserir(aluno);

                // limpando campos
                nome.setText("");
                curso.setText("");
                ra.setText("");

                Toast.makeText(this,"Aluno inserido com id: "+ id, Toast.LENGTH_SHORT).show();
            }else{
                Toast toast = Toast.makeText(this,Validador.validar(nome,curso,ra), Toast.LENGTH_SHORT);
                TextView v = (TextView) toast.getView().findViewById(android.R.id.message);
                v.setTextColor(Color.RED);
                toast.show();
            }

        }else{
            Aluno aluno = criarAluno(nome, curso, ra);
            // atualizando aluno no banco
            dao.atualizar(aluno);
            Toast.makeText(this,"Aluno foi atualizado", Toast.LENGTH_SHORT).show();
        }

    }

   // metodo usado para navegacao entre telas
    public  void irHome(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }




}
