package br.com.uninove.model;

import java.io.Serializable;

public class Aluno implements Serializable {

    private Long id;
    private String nome;
    private Double ra;
    private String curso;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getRA() {
        return ra;
    }

    public void setRA(Double ra) {
        this.ra = ra;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "{ " +
                " \"Nome\" : " + nome + ",\n" +
                "  \"RA\": " + ra + "\n" +
                " } ";
    }
}
