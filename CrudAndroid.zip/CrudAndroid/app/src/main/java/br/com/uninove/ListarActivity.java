package br.com.uninove;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.List;

import br.com.uninove.banco.AlunoDAO;
import br.com.uninove.model.Aluno;

public class ListarActivity extends AppCompatActivity {

    private ListView listView;
    private AlunoDAO dao;
    private List<Aluno> alunos;
    private List<Aluno> alunosFiltrados = new ArrayList<Aluno>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar);

        //Relacionando Java OBJ XML
        listView = findViewById(R.id.listProdutos);
        dao = new AlunoDAO(this);
        alunos = dao.listarTodos();
        alunosFiltrados.addAll(alunos);

        // Adaptador da Listagem
        ArrayAdapter<Aluno> adaptador = new ArrayAdapter<Aluno>(this, android.R.layout.simple_expandable_list_item_1, alunosFiltrados);
        listView.setAdapter(adaptador);

        // abri o contexto de menu com opcao (editar,excluir)
        registerForContextMenu(listView);

    }

    // exibir menu na tela de listagem
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater i = getMenuInflater();
        i.inflate(R.menu.menu_pesquisar, menu);

        SearchView sv = (SearchView) menu.findItem(R.id.app_bar_search).getActionView();
        // verifica se houve algo digitado
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                pesquisarAluno(s);
                return false;
            }
        });

        return true;
    }


    // metodo resposavel pela pesquisa por nome
    public void pesquisarAluno(String nome) {
        alunosFiltrados.clear();
        for (Aluno p : alunos) {
            if (p.getNome().toLowerCase().contains(nome.toLowerCase())) {
                alunosFiltrados.add(p);
            }
        }
        // para mostrar dados atualizados
        listView.invalidateViews();
    }


    // refresh na lista
    @Override
    public void onResume() {
        super.onResume();
        alunos = dao.listarTodos();
        alunosFiltrados.clear();
        alunosFiltrados.addAll(alunos);
        listView.invalidateViews();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.menu_contexto, menu);
    }


    public void excluir(MenuItem item){
        // Posição do item na Lista
        AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        final Aluno p = alunosFiltrados.get(menuInfo.position);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Atenção")
                .setMessage("Realmente deseja excluir o aluno ?")
                .setNegativeButton("Não", null)
                .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        alunosFiltrados.remove(p);
                        alunos.remove(p);
                        dao.excluir(p);
                        listView.invalidateViews();
                    }
                }).create();
        dialog.show();
    }


    public void atualizar(MenuItem item){
        // Posição do Item na Lista
        AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        //  Cria o aluno de acordo com a posição na lista 'alunosFiltrados'
        final Aluno p = alunosFiltrados.get(menuInfo.position);

        // Tela de cadastro
        Intent it = new Intent(this,CadastroActivity.class);
        it.putExtra("aluno", p);
        startActivity(it);
    }

    // Navegação entre telas
    public  void irHome(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}